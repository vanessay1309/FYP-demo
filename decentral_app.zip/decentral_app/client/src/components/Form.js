import React, { Component } from "react";


class Form extends Component {
  render() {
    return(
      <form>
      Name
      Description
      Social meida
      Facebook
      Instagram
      </form>

  );
  }
}
export default Form;

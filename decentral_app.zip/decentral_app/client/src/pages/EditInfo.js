import React, { Component } from "react";
class EditInfo extends Component {
  render() {
    return(
      <h1>Edit Information</h1>

    );
  }
}
export default EditInfo;
